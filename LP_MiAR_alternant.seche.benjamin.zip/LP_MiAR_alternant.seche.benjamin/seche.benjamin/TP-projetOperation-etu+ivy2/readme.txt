2.1 Question : code du projet
TestSimple : Classe de test JUnit testant la classe Operation.
TextThrowable : Classe de tests JUnit testant la classe Operation, s'attendant a lever des exceptions.
Operations : Classe mettant a dispo différentes opérations comme addition d'une liste de long ou autre.

2.2 Question : commandes java
Décrivez en français ce que réalise chacune des cinq commandes ci-dessous en explicitant leur paramétrage :
mkdir -p build/classes
	création du répertoire build et buil/classes. cette commande s'assure que chaque  répertoire  indiqué  existe : si les répertoires parents sont manquants, les créent. Ne lève pas d'erreur si les répertoires sont déjà existants.

javac -sourcepath src -d build/classes src/com/rpouiller/Operations.java
	javac : compilateur java. 
	-sourcepath indiqe le répertoire contenant les fichiers sources (ici, "src").
	-d indique la destination des fichiers .class qui seront créés (ici, "build/classes").
	-le fichier compilé est : src/com/rpouiller/Operations.java

echo "Main-Class: com.rpouiller.Operations">mf
	écrire "Main-Class: com.rpouiller.Operations" dans le fichier mf. Créé le fichier cible ("mf") si n'existe pas.

mkdir build/jar
	créé le dossier jar dans le dossier build. Lève une erreur si le fichier parent n'existe pas (ici, "build")

jar cfm build/jar/Operations.jar mf -C build/classes .
	jar : créé un jar. cfm indique les options : 
	option c : pour indiquer qu'il faut créer le jar
	option f : pour spécifier le nom du jar
	option m : pour spécifier le nom du manifest
	-C : pour spécifier le répertoire contenant les fichiers qui seront ajoutés au jar.
	le point à la fin indique que cette ligne concerne tous les fichiers de la racine.

java -jar build/jar/Operations.jar
	exécute le programme contenu dans le jar.

2.3 Question : cibles disponibles
Ces commandes utilisent le 
ant clean
	supprime le répertoire "build"

ant compile
	créé le répertoire "build/classes"
	compile tous les fichiers dans le répertoire "src" et met les fichiers classes dans "build/classes"

ant jar
	créé le répertoire "build/jar/"
	créé un fichier jar Operations.jar dans le dossier build/jar, les fichiers à mettre dans le jar se trouve dans "build/classes" et le manifest est créé avec un attribut "Main-Class" set à "com.rpouiller.Operations"
        
ant run
	exécute le programme contenu dans le jar Operations.jar. l'attribut fork à true déclenche l'exécution de la classe dans une autre machine virtuelle (permet un niveau de sécurité en cas de programme instable, sorte de mise en quarantaine. Si le java plante, ant ne le suivra pas de la tourmente)


Sans attributs description aux target, la commande ant -projecthelp ne nous révèle que très peu d'infos : seulement le nom des target.

Avec les descriptions, nous avons le noms des targets et leur descriptions. 


2.4 Question : propriétés par défaut
Les trois éléments cités sont effectivement définis par défaut.

ant.java.version permet de connaître la version de java
ant.version permet de connaître la version de ant



2.5 Question : amélioration du fichier build par globalisation

clean-build permet de : clean le build puis re-build après

main permet de : clean le build puis exécuter le jar


2.6 Question : spécification locale du classpath
dans l'élément java, classname et jar sont des attributs exclusifs : ils ne peuvent pas être utilisés en même temps.

2.7 Question 
traduction messages : 
Le chemin de votre classe n'est pas dans le classpath

[java] ERROR StatusLogger No log4j2 configuration file found. Using default configuration: logging only errors to the console.

Erreur de java : StatusLogger n'a pas trouvé de fichier de configurations log4j2. Il utilise la configuration par défaut : il enregistre que les erreurs dans la console.

Oui, même résultat, deux moyens différents.

2.8 Question : globalisation des classpath à l’aide de path

2.9 Question : compilation des tests

De quelle(s) cible(s) dépend la cible compile-test selon vous ? Rajoutez la dépendance.

La cible compile-test dépend de jar car elle a besoin d'Operations.jar pour compiler. On aurait pu aussi la faire dépendre d'une cible clean-test qui clean le buildTest.

2.10 Question : exécution des tests

De quelle(s) cible(s) dépend la cible junit selon vous ? Rajoutez la/les dépendance(s).
Elle dépend de la cible compile-test car elle a besoin des .class des tests.

2.11 Question : rapport de tests

De quelle(s) cible(s) dépend la cible junitreport selon vous ? Rajoutez la/les dépendance(s).
Elle dépend de la cible junit car elle a besoin que les tests soient exécutes

2.12 Question : génération de la javadoc
De quelle(s) cible(s) dépend la cible javadoc selon vous ? Rajoutez la/les dépendance(s).
La cible javadoc est indépendante car elle requiert uniquement les sources